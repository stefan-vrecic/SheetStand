package com.example.a3pagepdf.viewer

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject

/**
 * A single favourited PDF: the persisted-permission URI plus a display
 * name captured at the time it was added (so we don't need to re-query
 * the content resolver every time the grid renders).
 */
data class FavoriteItem(
    val uri: Uri,
    val name: String
)

/**
 * Persists the user's favourite PDFs (used to back the 2x4 favourites grid
 * on HomeActivity) as a small JSON array in the same "pdf_prefs" prefs file
 * that PdfPersistence already uses. Capped at [MAX_FAVORITES] since the grid
 * itself is a fixed 2x4 layout, not a scrolling list.
 */
object FavoritesStore {
    const val MAX_FAVORITES = 8

    private const val PREFS_NAME = "pdf_prefs"
    private const val KEY = "favorite_pdfs"

    fun load(context: Context): List<FavoriteItem> {
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY, null) ?: return emptyList()

        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val obj = arr.optJSONObject(i) ?: return@mapNotNull null
                val uriString = obj.optString("uri").takeIf { it.isNotBlank() } ?: return@mapNotNull null
                FavoriteItem(uri = Uri.parse(uriString), name = obj.optString("name", "PDF"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** Returns false (and does nothing) if [uri] is already favourited or the grid is full. */
    fun add(context: Context, uri: Uri, name: String): Boolean {
        val current = load(context)
        if (current.size >= MAX_FAVORITES) return false
        if (current.any { it.uri == uri }) return false

        val updated = current + FavoriteItem(uri, name)
        persist(context, updated)
        return true
    }

    fun remove(context: Context, uri: Uri) {
        val updated = load(context).filterNot { it.uri == uri }
        persist(context, updated)
    }

    fun isFavorite(context: Context, uri: Uri): Boolean =
        load(context).any { it.uri == uri }

    private fun persist(context: Context, items: List<FavoriteItem>) {
        val arr = JSONArray()
        items.forEach { item ->
            arr.put(
                JSONObject().apply {
                    put("uri", item.uri.toString())
                    put("name", item.name)
                }
            )
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY, arr.toString())
            .apply()
    }

    /** Best-effort display name for a freshly-picked document Uri (e.g. from OpenDocument). */
    fun queryDisplayName(context: Context, uri: Uri): String {
        return try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
            } ?: uri.lastPathSegment ?: "PDF"
        } catch (e: Exception) {
            uri.lastPathSegment ?: "PDF"
        }
    }
}
