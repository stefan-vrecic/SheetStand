package com.example.a3pagepdf

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.example.a3pagepdf.viewer.AutoScrollEffect
import com.example.a3pagepdf.viewer.AutoScrollTopBar
import com.example.a3pagepdf.viewer.MetronomeEffect
import com.example.a3pagepdf.viewer.PageTimerEffect
import com.example.a3pagepdf.viewer.PdfPageList
import com.example.a3pagepdf.viewer.PdfPageSource
import com.example.a3pagepdf.viewer.SpeedControlRow
import com.example.a3pagepdf.viewer.rememberAutoScrollState
import com.example.a3pagepdf.viewer.rememberMetronomeState
import com.example.a3pagepdf.viewer.rememberPageTimerState

class AutoScrollActivity : ComponentActivity() {

    private lateinit var pageSource: PdfPageSource

    private val openDocLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { pageSource.openPdf(it, isNewSelection = true) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pageSource = PdfPageSource(contentResolver, this)

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Column(modifier = Modifier.fillMaxSize()) {

                        val listState = rememberLazyListState()
                        val currentVisiblePage by remember {
                            derivedStateOf { listState.firstVisibleItemIndex + 1 }
                        }

                        val autoScroll = rememberAutoScrollState()
                        val timer = rememberPageTimerState()
                        val metronome = rememberMetronomeState()

                        AutoScrollTopBar(
                            pageSource = pageSource,
                            listState = listState,
                            currentVisiblePage = currentVisiblePage,
                            autoScroll = autoScroll,
                            timer = timer,
                            metronome = metronome,
                            onOpenPdf = { openDocLauncher.launch(arrayOf("application/pdf")) }
                        )

                        SpeedControlRow(autoScroll)

                        // Side-effect loops driving each feature
                        AutoScrollEffect(autoScroll, listState)
                        PageTimerEffect(timer, listState, currentVisiblePage, pageSource.pageCount)
                        MetronomeEffect(metronome)

                        PdfPageList(pageSource, listState)
                    }
                }
            }
        }

        pageSource.loadLastPdfIfAvailable()
    }

    override fun onDestroy() {
        super.onDestroy()
        pageSource.release()
    }
}