package com.example.a3pagepdf.viewer

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * A fixed 2-row x 4-column grid of favourited PDFs, meant to sit at the
 * bottom of HomeActivity. Filled slots show a first-page thumbnail and open
 * the PDF on tap; the first empty slot is always an "add" tile that launches
 * a document picker (wired up by the caller via [onAddClick]). Long-press on
 * a filled tile asks to remove it from favourites.
 *
 * Stateless/host-driven on purpose so HomeActivity owns the favourites list
 * and persistence — this component only renders it and reports intent.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FavoritesGrid(
    favorites: List<FavoriteItem>,
    onOpen: (FavoriteItem) -> Unit,
    onAddClick: () -> Unit,
    onRemove: (FavoriteItem) -> Unit,
    modifier: Modifier = Modifier,
    columns: Int = 4,
    rows: Int = 2
) {
    val totalSlots = columns * rows
    var pendingRemoval by remember { mutableStateOf<FavoriteItem?>(null) }

    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = "Favourites",
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.padding(bottom = 10.dp)
        )

        for (row in 0 until rows) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = if (row < rows - 1) 10.dp else 0.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                for (col in 0 until columns) {
                    val index = row * columns + col
                    Box(modifier = Modifier.weight(1f)) {
                        when {
                            index < favorites.size -> FavoriteTile(
                                item = favorites[index],
                                onClick = { onOpen(favorites[index]) },
                                onLongClick = { pendingRemoval = favorites[index] }
                            )
                            index == favorites.size && favorites.size < totalSlots -> AddFavoriteTile(onClick = onAddClick)
                            else -> EmptyFavoriteSlot()
                        }
                    }
                }
            }
        }
    }

    pendingRemoval?.let { item ->
        AlertDialog(
            onDismissRequest = { pendingRemoval = null },
            title = { Text("Remove from Favourites?") },
            text = { Text(item.name) },
            confirmButton = {
                TextButton(onClick = {
                    onRemove(item)
                    pendingRemoval = null
                }) { Text("Remove") }
            },
            dismissButton = {
                TextButton(onClick = { pendingRemoval = null }) { Text("Cancel") }
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FavoriteTile(
    item: FavoriteItem,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val context = LocalContext.current
    var thumbnail by remember(item.uri) { mutableStateOf(FavoriteThumbnailLoader.cache[item.uri.toString()]) }

    LaunchedEffect(item.uri) {
        if (thumbnail == null) {
            thumbnail = FavoriteThumbnailLoader.thumbnailFor(context, item.uri)
        }
    }

    Column(
        modifier = Modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 3.dp,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(0.72f)
        ) {
            val bmp = thumbnail
            if (bmp != null) {
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = item.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                    )
                }
            }
        }
        Text(
            text = item.name,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f),
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
private fun AddFavoriteTile(onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.12f),
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.72f)
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "Add favourite",
                tint = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f)
            )
        }
    }
}

@Composable
private fun EmptyFavoriteSlot() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.72f)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.05f))
    )
}
