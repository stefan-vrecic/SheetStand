package com.example.a3pagepdf.viewer

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
//import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

/**
 * Top control row for AutoScrollActivity: Open / Play-Pause / prev-next page
 * jump / page indicator / metronome beat lights + control / timer control /
 * metronome pause-resume.
 */
@Composable
fun AutoScrollTopBar(
    pageSource: PdfPageSource,
    listState: LazyListState,
    currentVisiblePage: Int,
    autoScroll: AutoScrollState,
    timer: PageTimerState,
    metronome: MetronomeState,
    onOpenPdf: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CompactButton(onClick = onOpenPdf) {
            Text("Open")
        }
        Spacer(modifier = Modifier.width(8.dp))
        CompactButton(onClick = {
            autoScroll.togglePlay(onPlayStarted = { timer.isActive = false })
        }) {
            Text(if (autoScroll.isPlaying) "Pause" else "Play")
        }
        if (autoScroll.delayCountdown != null) {
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Starting in ${autoScroll.delayCountdown}…",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(modifier = Modifier.width(16.dp))
        CompactButton(onClick = {
            autoScroll.stop()
            val targetIndex = (currentVisiblePage - 2).coerceAtLeast(0)
            coroutineScope.launch { listState.animateScrollToItem(targetIndex) }
        }) {
            Text("◀–")
        }
        Spacer(modifier = Modifier.width(8.dp))
        CompactButton(onClick = {
            autoScroll.stop()
            val targetIndex = currentVisiblePage.coerceAtMost(pageSource.pageCount - 1)
            coroutineScope.launch { listState.animateScrollToItem(targetIndex) }
        }) {
            Text("–▶")
        }
        Spacer(modifier = Modifier.width(16.dp))
        if (pageSource.pageCount > 0) {
            Text("$currentVisiblePage of ${pageSource.pageCount}")
        }

        if (metronome.isOn) {
            Spacer(modifier = Modifier.width(16.dp))
            MetronomeBeatLights(metronome)
        }

        Spacer(modifier = Modifier.weight(1f))

        MetronomeControl(metronome)
        Spacer(modifier = Modifier.width(8.dp))

        TimerControl(
            state = timer,
            pageCount = pageSource.pageCount,
            onActivate = { autoScroll.stop() }
        )

        if (metronome.isOn) {
            Spacer(modifier = Modifier.width(8.dp))
            CompactButton(onClick = { metronome.isPaused = !metronome.isPaused }) {
                Text(if (metronome.isPaused) "Start" else "Pause")
            }
        }
    }
}
