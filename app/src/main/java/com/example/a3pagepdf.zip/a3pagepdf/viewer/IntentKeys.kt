package com.example.a3pagepdf.viewer

/** Intent extra used by HomeActivity's favourites grid to hand a PDF straight to a viewer mode. */
const val EXTRA_PDF_URI = "extra_pdf_uri"
